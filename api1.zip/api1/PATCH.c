	
	PATCH()
{
		
		web_add_header("content-type",
		"json");

		
	web_add_header("usertype",
		"value");

		web_reg_save_param_regexp(
		"ParamName=c_name",
		"RegExp=name\":\"(.*?)\",\"jo",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
		
		web_reg_save_param_regexp(
		"ParamName=c_job",
		"RegExp=job\":\"(.*?)\",\"up",
		SEARCH_FILTERS,
		"Scope=BODY",
		"IgnoreRedirections=Yes",
		LAST);

		
	web_custom_request("web_custom_request",
		"URL=https://reqres.in/api/users/{p_user}",
		"Method=PATCH",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\r\n"
		"    \"name\": \"{p_names}\",\r\n"
		"    \"job\": \"{p_jobs}\"\r\n"
		"}",
		LAST);		
		
		
	return 0;
}
