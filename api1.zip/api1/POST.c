POST()
{
	web_add_header("content-type",
		"json");


	web_add_header("usertype",
		"value");


	

	
	web_custom_request("web_custom_request",
		"URL=https://reqres.in/api/user",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=apllication/json",
		"Body={\r\n"
		"    \"name\": \"{c_name}\",\r\n"
		"    \"job\": \"{c_job}\"\r\n"
		"}",
		LAST);
	
	web_reg_save_param_regexp(
		"ParamName=c_token",
		"RegExp=token\":\"(.*?)\"",
		SEARCH_FILTERS,
		"Scope=BODY",
		"IgnoreRedirections=Yes",
		LAST);

	
	
	web_custom_request("web_custom_request",
		"URL=https://reqres.in/api/login",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\r\n"
		"    \"email\": \"eve.holt@reqres.in\",\r\n"
		"    \"password\": \"cityslicka\"\r\n"
		"}",
		LAST);
	
	
	


	return 0;
}
