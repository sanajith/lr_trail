GET()
{
//	web_add_header("content-type",
//		"json");
//
//	
//	web_add_header("usertype",
//		"value");

	
	
	
	web_custom_request("web_custom_request",
		"URL=https://reqres.in/api/users?page=2",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=application/json",
		"Body=",
		LAST);
	
	lr_start_transaction("GET2");
	
	
	web_add_header("content-type",
		"json");

	
	web_add_header("usertype",
		"value");

	web_reg_save_param_regexp(
		"ParamName=c_email",
		"RegExp=,\"email\":\"(.*?)\",\"first",
		"Ordinal=1",
		SEARCH_FILTERS,
		"Scope=BODY",
		"IgnoreRedirections=Yes",
		LAST);

	
	
	web_custom_request("web_custom_request",
		"URL=https://reqres.in/api/users/{p_user}",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=application/json",
		"Body=",
		LAST);

	
lr_end_transaction("GET2", LR_AUTO);


	
	
	return 0;
}

	