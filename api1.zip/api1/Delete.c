Delete()
{
	web_add_header("content-type",
		"json");

	
	web_add_header("usertype",
		"value");

	
	
	web_custom_request("web_custom_request",
		"URL=https://reqres.in/api/users/{p_user}",
		"Method=DELETE",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Mode=HTML",
		"EncType=application/json",
		"Body=",
		LAST);

	return 0;
}
